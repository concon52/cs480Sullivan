// Shader loader class
class ShaderLoader
{
    public:
        ShaderLoader();
        static char* LoadShader(const char* FilePath);
};


